package com.admin.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.admin.dao.AddLibrarianRepo;
import com.admin.entity.AddLibrarian;

@Service
public class AddLibrarianService {
	@Autowired
	private AddLibrarianRepo librepo;
	//view data
	public List<AddLibrarian> fetchLibrarianList(){
		return librepo.findAll();
		
	}
	//add data
	public AddLibrarian saveLibrarianToDB(AddLibrarian librarian)
	{
		return librepo.save(librarian);
	}
	
	//find by id
	public Optional<AddLibrarian> fetchLibrarianById(int lid) {
		return librepo.findById(lid);	
	}
	
public String deleteLibrarianById(int lid) {
		
		String result;
		try { 
			librepo.deleteById(lid);
		result = "Librarian successfully deleted";
		
		
	}catch (Exception e) {
		result = "Librarian with id is not deleted";
	
	}
		return result;
	}
}
