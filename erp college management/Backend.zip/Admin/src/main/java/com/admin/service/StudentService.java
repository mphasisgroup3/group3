package com.admin.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.admin.dao.StudentRepository;
import com.admin.entity.Student;


@Service
public class StudentService {

	@Autowired
	private StudentRepository sturepo;
	//view data
	public List<Student> fetchStudentList(){
		return sturepo.findAll();
		
	}
	//add data
	public Student saveStudentToDB(Student student)
	{
		return sturepo.save(student);
	}
	
	//find by id
	public Optional<Student> fetchStudentById(int stid) {
		return sturepo.findById(stid);	
	}
	
public String deleteStudentById(int stid) {
		
		String result;
		try { 
			sturepo.deleteById(stid);
		result = "Student successfully deleted";
		
		
	}catch (Exception e) {
		result = "Student with id is not deleted";
	
	}
		return result;
	}
	
}
