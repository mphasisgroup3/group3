package com.admin.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.admin.entity.AddFaculty;
import com.admin.service.AddFacultyService;

@RestController
public class AddFacultyController {
	@Autowired
	private AddFacultyService fservice;

	@CrossOrigin(origins = "http://localhost:4200")
	@GetMapping(value = "/getfacultylist")
	public List<AddFaculty> fetchAddFacultyList() {
		List<AddFaculty> getfaculty = new ArrayList<AddFaculty>();
		getfaculty = fservice.fetchAddFacultyList();
		return getfaculty;
	}

	@CrossOrigin(origins = "http://localhost:4200")
	@PostMapping(value = "/addfaculty")
	public AddFaculty saveAddFaculty(@RequestBody AddFaculty addfaculty) {
		return fservice.saveAddFacultyToDB(addfaculty);
	}

	@CrossOrigin(origins = "http://localhost:4200")
	@GetMapping("/getfacultybyid/{fid}")
	public AddFaculty fetchAddFacultyById(@PathVariable int fid) {
		return fservice.fetchAddFacultyById(fid).get();
	}

	@CrossOrigin(origins = "http://localhost:4200")
	@DeleteMapping("/deletefacultybyid/{fid}")
	public String DeleteAddFacultyById(@PathVariable int fid) {
		return fservice.deleteAddFacultyById(fid);
	}

}
