package com.admin.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.admin.entity.AddFaculty;



public interface AddFacultyRepo extends JpaRepository<AddFaculty, Integer>{

}
