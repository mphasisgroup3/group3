package com.admin.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="lprofile")
public class AddLibrarian {
	
	
		@Id
	private int lid;
	private String lname;
	private String lemail;
	private String lphone;
	private String lpin;
	
	

	public AddLibrarian() {}

	public AddLibrarian(int lid, String lname, String lemail, String lphone, String lpin) {
		super();
		this.lid = lid;
		this.lname = lname;
		this.lemail = lemail;
		this.lphone = lphone;
		this.lpin = lpin;
	}


	


	public int getLid() {
		return lid;
	}


	public void setLid(int lid) {
		this.lid = lid;
	}


	public String getLname() {
		return lname;
	}


	public void setLname(String lname) {
		this.lname = lname;
	}


	public String getLemail() {
		return lemail;
	}


	public void setLemail(String lemail) {
		this.lemail = lemail;
	}


	public String getLphone() {
		return lphone;
	}


	public void setLphone(String lphone) {
		this.lphone = lphone;
	}


	public String getLpin() {
		return lpin;
	}


	public void setLpin(String lpin) {
		this.lpin = lpin;
	}

}
