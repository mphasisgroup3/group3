package com.admin.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="fprofile")
public class AddFaculty {
	
			@Id
	private int fid;
	private String fname;
	private String femail;
	private String fphone;
	private String fpin;
	private String fdepartment;
	
	
public AddFaculty() {}

public AddFaculty(int fid, String fname, String femail, String fphone, String fpin, String fdepartment) {
		super();
		this.fid = fid;
		this.fname = fname;
		this.femail = femail;
		this.fphone = fphone;
		this.fpin = fpin;
		this.fdepartment = fdepartment;
	}



	public int getFid() {
		return fid;
	}

	public void setFid(int fid) {
		this.fid = fid;
	}

	public String getFname() {
		return fname;
	}

	public void setFname(String fname) {
		this.fname = fname;
	}

	public String getFemail() {
		return femail;
	}

	public void setFemail(String femail) {
		this.femail = femail;
	}

	public String getFphone() {
		return fphone;
	}

	public void setFphone(String fphone) {
		this.fphone = fphone;
	}

	public String getFpin() {
		return fpin;
	}

	public void setFpin(String fpin) {
		this.fpin = fpin;
	}

	public String getFdepartment() {
		return fdepartment;
	}

	public void setFdepartment(String fdepartment) {
		this.fdepartment = fdepartment;
	}
}
	

