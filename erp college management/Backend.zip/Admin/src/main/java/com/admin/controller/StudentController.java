package com.admin.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.admin.entity.Student;
import com.admin.service.StudentService;

@RestController
public class StudentController {
	@Autowired
	private StudentService stuservice;

	@CrossOrigin(origins = "http://localhost:4200")
	@GetMapping(value = "/getstudentlist")
	public List<Student> fetchStudentList() {
		List<Student> students = new ArrayList<Student>();
		students = stuservice.fetchStudentList();
		return students;
	}

	@CrossOrigin(origins = "http://localhost:4200")
	@PostMapping(value = "/addstudent")
	public Student saveStudent(@RequestBody Student student) {
		return stuservice.saveStudentToDB(student);
	}

	@CrossOrigin(origins = "http://localhost:4200")
	@GetMapping("/getstudentbyid/{stid}")
	public Student fetchStudentById(@PathVariable int stid) {
		return stuservice.fetchStudentById(stid).get();
	}

	@CrossOrigin(origins = "http://localhost:4200")
	@DeleteMapping("/deletestudentbyid/{stid}")
	public String DeleteStudentById(@PathVariable int stid) {
		return stuservice.deleteStudentById(stid);
	}

}
